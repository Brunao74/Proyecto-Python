from django.apps import AppConfig


class ProyAdministracionConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ProyAdministracion'
